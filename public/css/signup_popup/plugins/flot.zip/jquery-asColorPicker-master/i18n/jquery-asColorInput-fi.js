// asColorPicker
// Finnish (fi) localization

(function($) {
    var localization = $.asColorPicker.localization["fi"] = {
        cancelText: "Kumoa",
        applyText: "Valitse"
    };
    $.extend($.asColorPicker.defaults.buttons, localization);
})(jQuery);