=== HotelBooking ===
Contributors: nicdark, cleanthemes
Requires at least: WordPress 4.4
Tested up to: WordPress 4.8
Version: 1.0
Tags: one-column, two-columns, right-sidebar, custom-header, custom-menu, editor-style, featured-images, microformats, post-formats, rtl-language-support, sticky-post, translation-ready, accessibility-ready

== Description ==
Hotel Booking perfect WP themes for any hotel, resort, booking and travel activities.


== Installation ==

1. In your admin panel, go to Appearance -> Themes and click the 'Add New' button.
2. Upload the zip package ( Hotelbooking.zip )
3. Click on the 'Activate' button to use your new theme right away.
4. Install required plugins
5. Navigate to Appearance > Customize in your admin panel and customize to taste.

== Copyright ==

Hotelbooking Theme, Copyright 2017 Nicdark Themes

